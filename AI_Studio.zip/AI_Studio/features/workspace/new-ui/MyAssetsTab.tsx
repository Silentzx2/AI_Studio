"use client";
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import anime from 'animejs';
import { Search, Folder, Trash2, Heart, Play, Cpu, LayoutGrid, Clock } from 'lucide-react';
import { HistoryItem } from '@/types/new-ui';
import { ProjectTimeline } from '@/components/ActivityLogger';

interface MyAssetsTabProps {
  history: HistoryItem[];
  onLoadProject: (item: HistoryItem) => void;
  onDeleteProject: (e: React.MouseEvent, id: string) => void;
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
}

export default function MyAssetsTab({
  history,
  onLoadProject,
  onDeleteProject,
  onToggleFavorite,
}: MyAssetsTabProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [formatFilter, setFormatFilter] = useState<'ALL' | 'GLB' | 'OBJ' | 'FBX'>('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'timeline'>('timeline');
  
  const filteredHistory = history.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.prompt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFormat = formatFilter === 'ALL' || item.format === formatFilter;
    return matchesSearch && matchesFormat;
  });

  useEffect(() => {
    if (viewMode === 'grid') {
      anime({
        targets: '#my-assets-grid > div',
        opacity: [0, 1],
        translateY: [20, 0],
        delay: anime.stagger(30),
        easing: 'easeOutQuad',
        duration: 500
      });
    }
  }, [filteredHistory.length, viewMode]);

  return (
    <div className="flex-1 min-h-0 p-5 flex flex-col gap-5 animate-fadeIn text-[hsl(var(--foreground))] overflow-y-auto" id="my-assets-tab-panel">
      {/* Intro section with refined Studio layout */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[hsl(var(--primary))]/10 flex items-center justify-center border border-[hsl(var(--primary))]/20">
            <Folder size={20} className="text-[hsl(var(--primary))]" />
          </div>
          <div>
            <h2 className="text-xl font-black text-[hsl(var(--foreground))] uppercase tracking-tight">Project Library &amp; History</h2>
            <div className="flex items-center gap-2 mt-0.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--primary))] animate-pulse" />
              <p className="text-[10px] font-bold text-[hsl(var(--muted-foreground))] uppercase tracking-widest">
                {history.length} Assets Synchronized
              </p>
            </div>
          </div>
        </div>

        {/* View Switcher: Gallery vs Project Timeline */}
        <div className="flex p-1 rounded-xl bg-[hsl(var(--surface-1))] border border-[hsl(var(--border))]">
          <button
            onClick={() => setViewMode('timeline')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'timeline'
                ? 'bg-[hsl(var(--primary))] text-[hsl(var(--foreground))] shadow-sm'
                : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'
            }`}
          >
            <Clock size={13} />
            <span>Project Timeline</span>
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'grid'
                ? 'bg-[hsl(var(--primary))] text-[hsl(var(--foreground))] shadow-sm'
                : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'
            }`}
          >
            <LayoutGrid size={13} />
            <span>Grid Gallery</span>
          </button>
        </div>
      </div>

      {viewMode === 'timeline' ? (
        /* Visual Project Timeline from ActivityLogger */
        <ProjectTimeline onLoadProject={onLoadProject} />
      ) : (
        /* Grid Gallery View */
        <>
          {/* Search and Filters Header */}
          <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center bg-[hsl(var(--surface-1))] border border-[hsl(var(--border))] rounded-2xl p-4" id="assets-control-bar">
            {/* Search */}
            <div className="relative w-full md:w-80" id="assets-search-wrapper">
              <Search size={15} className="absolute left-3 top-3.5 text-[hsl(var(--muted-foreground))]" />
              <input
                type="text"
                placeholder="Search generated assets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[hsl(var(--surface-2))] border border-[hsl(var(--border))] rounded-xl py-2.5 pl-10 pr-4 text-xs text-[hsl(var(--foreground))] placeholder-[hsl(var(--muted-foreground))] focus:outline-none focus:border-[hsl(var(--border))] transition-all"
                id="assets-search-input"
              />
            </div>

            {/* Format Select Filter */}
            <div className="flex gap-2 w-full md:w-auto" id="format-filters-group">
              {(['ALL', 'GLB', 'OBJ', 'FBX'] as const).map((fmt) => (
                <button
                  key={fmt}
                  onClick={() => setFormatFilter(fmt)}
                  className={`flex-1 md:flex-initial px-4 py-2 rounded-lg text-xs font-medium transition-all border border-transparent ${
                    formatFilter === fmt
                      ? 'bg-[hsl(var(--surface-2))] text-[hsl(var(--foreground))]'
                      : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'
                  }`}
                  id={`format-filter-btn-${fmt}`}
                >
                  {fmt}
                </button>
              ))}
            </div>
          </div>

          {/* Grid of Assets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5" id="my-assets-grid">
            {filteredHistory.map((item) => (
              <div
                key={item.id}
                onClick={() => onLoadProject(item)}
                className="card-minimal p-3 flex flex-col gap-3 cursor-pointer transition-all hover:border-[hsl(var(--border))]/[0.3]"
                id={`asset-card-${item.id}`}
              >
                {/* Visual Box representation of geometric mesh */}
                <div className="relative aspect-square w-full rounded-xl bg-[hsl(var(--surface-2))] border border-[hsl(var(--border)/0.2)] overflow-hidden flex items-center justify-center" id={`asset-thumb-box-${item.id}`}>
                  {item.thumbnailUrl ? (
                    <img src={item.thumbnailUrl} alt={item.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-16 h-16 rounded bg-[hsl(var(--surface-1))] border border-[hsl(var(--border)/0.3)] flex items-center justify-center" id={`asset-geom-${item.id}`}>
                      <Cpu size={28} className="text-[hsl(var(--muted-foreground))]/60" />
                    </div>
                  )}

                  {/* Floating top controls */}
                  <div className="absolute top-2.5 right-2.5 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity" id={`asset-floating-tools-${item.id}`}>
                    <button
                      onClick={(e) => onToggleFavorite(e, item.id)}
                      className={`p-2 rounded-lg bg-[hsl(var(--surface-0)/0.8)] hover:bg-black text-xs transition-all ${
                        item.isFavorite ? 'text-[hsl(var(--destructive))]' : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'
                      }`}
                      title="Favorite model"
                      id={`asset-fav-btn-${item.id}`}
                    >
                      <Heart size={12} className={item.isFavorite ? 'fill-[hsl(var(--destructive))]' : ''} />
                    </button>
                    <button
                      onClick={(e) => onDeleteProject(e, item.id)}
                      className="p-2 rounded-lg bg-[hsl(var(--surface-0)/0.8)] hover:bg-[hsl(var(--destructive)/0.1)] text-xs text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--destructive))] transition-all"
                      title="Delete model"
                      id={`asset-del-btn-${item.id}`}
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>

                  {/* Format Badge */}
                  <div className="absolute bottom-2.5 left-2.5" id={`asset-format-badge-container-${item.id}`}>
                    <span className="px-2 py-0.5 rounded bg-[hsl(var(--surface-0)/0.9)] text-[9px] font-medium text-[hsl(var(--foreground))] border border-[hsl(var(--border)/0.3)] uppercase">
                      {item.format}
                    </span>
                  </div>
                </div>

                {/* Labels */}
                <div className="flex flex-col gap-1" id={`asset-meta-${item.id}`}>
                  <div className="flex justify-between items-start gap-1">
                    <span className="text-xs font-medium text-[hsl(var(--foreground))] truncate group-hover:text-[hsl(var(--foreground))] transition-colors" id={`asset-title-${item.id}`}>
                      {item.name}
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-[hsl(var(--foreground)/0.04)] text-[9px] font-mono text-[hsl(var(--muted-foreground))]">PBR</span>
                  </div>
                  <p className="text-[10px] text-[hsl(var(--muted-foreground))] line-clamp-1 truncate" id={`asset-prompt-${item.id}`}>
                    {item.prompt}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-[hsl(var(--muted-foreground))] font-mono mt-2 pt-2 border-t border-[hsl(var(--border))]/[0.03]">
                    <span>🕒 {item.timestamp}</span>
                    <span className="text-[hsl(var(--foreground))] font-sans font-medium flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      Open <Play size={8} />
                    </span>
                  </div>
                </div>
              </div>
            ))}

             {filteredHistory.length === 0 && (
              <div className="col-span-full bg-[hsl(var(--surface-1))] border border-dashed border-[hsl(var(--border)/0.2)] rounded-2xl p-12 text-center flex flex-col items-center justify-center text-[hsl(var(--muted-foreground))]" id="assets-empty-placeholder">
                <Folder size={40} className="text-[hsl(var(--border))] mb-3" />
                <p className="text-xs font-medium text-[hsl(var(--foreground))]">No assets found</p>
                <p className="text-[10px] mt-1">Try tweaking your search terms, changing the format filter, or create a new mesh!</p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
