import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { 
  ToolType, 
  MainNavRoute, 
  ShadingMode, 
  ModelAsset, 
  MaterialConfig, 
  BoneNode, 
  AnimationTrack, 
  ComfySystemStats,
  GenerationSettings,
  RemeshSettings,
  TextureSettings,
  AnimateSettings,
  RiggingSettings,
  SegmentationSettings,
  ComfyActiveTask
} from '../types';
import { DEFAULT_HUMANOID_SKELETON } from '../lib/geometry';
import { comfyClient } from '../lib/comfy';

interface WorkspaceContextType {
  // Navigation & Tool states
  activeTool: ToolType;
  setActiveTool: (tool: ToolType) => void;
  mainNav: MainNavRoute;
  setMainNav: (nav: MainNavRoute) => void;
  
  // Asset Management
  assets: ModelAsset[];
  selectedAssetId: string;
  currentAsset: ModelAsset | null;
  selectAsset: (id: string) => void;
  updateAssetProperties: (id: string, updates: Partial<ModelAsset>) => void;
  updateMaterialConfig: (updates: Partial<MaterialConfig>) => void;
  deleteAsset: (id: string) => void;
  addAsset: (asset: ModelAsset) => void;

  // Viewport Settings
  shadingMode: ShadingMode;
  setShadingMode: (mode: ShadingMode) => void;
  showWireframe: boolean;
  setShowWireframe: (show: boolean) => void;
  showGrid: boolean;
  setShowGrid: (show: boolean) => void;
  showBones: boolean;
  setShowBones: (show: boolean) => void;
  isTurntable: boolean;
  setIsTurntable: (turntable: boolean) => void;
  activeTransformTool: 'select' | 'rotate' | 'pan' | 'frame';
  setActiveTransformTool: (tool: 'select' | 'rotate' | 'pan' | 'frame') => void;
  viewportResetTrigger: number;
  resetCamera: () => void;
  fitToScreen: () => void;

  // Panels & Tabs
  activeRightTab: 'assets' | 'property' | 'properties' | 'prompt';
  setActiveRightTab: (tab: 'assets' | 'property' | 'properties' | 'prompt') => void;
  rightPanelMode: 'assets' | 'property' | 'properties' | 'prompt';
  setRightPanelMode: (mode: 'assets' | 'property' | 'properties' | 'prompt') => void;
  isLeftPanelOpen: boolean;
  setIsLeftPanelOpen: (open: boolean) => void;
  toolPanelOpen: boolean;
  setToolPanelOpen: (open: boolean) => void;
  isRightPanelOpen: boolean;
  setIsRightPanelOpen: (open: boolean) => void;
  rightPanelOpen: boolean;
  setRightPanelOpen: (open: boolean) => void;

  // Asset Filter & Duplicate
  setCurrentAsset: (asset: ModelAsset) => void;
  assetFilter: string;
  setAssetFilter: (filter: string) => void;
  duplicateAsset: (id: string) => void;

  // ComfyUI State
  comfyStats: ComfySystemStats;
  isComfySettingsOpen: boolean;
  setIsComfySettingsOpen: (open: boolean) => void;
  isExportModalOpen: boolean;
  setIsExportModalOpen: (open: boolean) => void;
  isDccBridgeOpen: boolean;
  setIsDccBridgeOpen: (open: boolean) => void;
  refreshComfyStats: () => Promise<void>;

  // Real-time ComfyUI Queue & Task Overlay Feedback
  activeTask: ComfyActiveTask | null;
  dismissActiveTask: () => void;

  // Execution & Generation Status
  isExecuting: boolean;
  executionProgress: number;
  executionStep: string;
  cancelExecution: () => void;

  // Tool Specific Configurations
  generationSettings: GenerationSettings;
  setGenerationSettings: React.Dispatch<React.SetStateAction<GenerationSettings>>;
  remeshSettings: RemeshSettings;
  setRemeshSettings: React.Dispatch<React.SetStateAction<RemeshSettings>>;
  textureSettings: TextureSettings;
  setTextureSettings: React.Dispatch<React.SetStateAction<TextureSettings>>;
  animateSettings: AnimateSettings;
  setAnimateSettings: React.Dispatch<React.SetStateAction<AnimateSettings>>;
  riggingSettings: RiggingSettings;
  setRiggingSettings: React.Dispatch<React.SetStateAction<RiggingSettings>>;
  segmentationSettings: SegmentationSettings;
  setSegmentationSettings: React.Dispatch<React.SetStateAction<SegmentationSettings>>;

  // Rigging & Animation specific
  bones: BoneNode[];
  selectedBoneId: string | null;
  setSelectedBoneId: (id: string | null) => void;
  updateBone: (id: string, updates: Partial<BoneNode>) => void;
  currentFrame: number;
  setCurrentFrame: (frame: number) => void;
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  totalFrames: number;
  fps: number;
  tracks: AnimationTrack[];

  // Generation Actions
  generate3DModel: () => Promise<void>;
  generateTextTo3D: (customPrompt?: string) => Promise<void>;
  generateImageTo3D: (customImage?: string) => Promise<void>;
  runModelGeneration: () => Promise<void>;
  runRemeshGeneration: () => Promise<void>;
  runTextureGeneration: () => Promise<void>;
  runAnimateGeneration: () => Promise<void>;
  runRiggingGeneration: () => Promise<void>;
  runSegmentationGeneration: () => Promise<void>;
  queueComfyWorkflow: (workflow: Record<string, unknown>, type: ComfyActiveTask['type'], title: string) => Promise<void>;
}

const WorkspaceContext = createContext<WorkspaceContextType | undefined>(undefined);

export const WorkspaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation
  const [activeTool, setActiveTool] = useState<ToolType>('model');
  const [mainNav, setMainNav] = useState<MainNavRoute>('workspace');
  
  // Right panel tabs
  const [activeRightTab, setActiveRightTab] = useState<'assets' | 'property' | 'prompt'>('assets');
  const [isLeftPanelOpen, setIsLeftPanelOpen] = useState(true);
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(true);

  // Asset list & active selection
  const [assets, setAssets] = useState<ModelAsset[]>([]);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [assetFilter, setAssetFilter] = useState<string>('all');

  // Viewport display states
  const [shadingMode, setShadingMode] = useState<ShadingMode>('textured');
  const [showWireframe, setShowWireframe] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [showBones, setShowBones] = useState(false);
  const [isTurntable, setIsTurntable] = useState(false);
  const [activeTransformTool, setActiveTransformTool] = useState<'select' | 'rotate' | 'pan' | 'frame'>('select');
  const [viewportResetTrigger, setViewportResetTrigger] = useState(0);

  // ComfyUI backend stats
  const [comfyStats, setComfyStats] = useState<ComfySystemStats>({
    status: 'offline',
    host: 'http://127.0.0.1:8188',
    gpu: 'Unavailable',
    vramUsedGb: null,
    vramTotalGb: null,
    ramUsedGb: null,
    ramTotalGb: null,
    torchVramUsedGb: null,
    torchVramTotalGb: null,
    gpuType: null,
    gpuIndex: null,
    pythonVersion: null,
    torchVersion: null,
    comfyVersion: null,
    pack3dVersion: null,
    queueRunning: 0,
    queuePending: 0,
    activePromptId: null,
    activeNode: null,
    lastPingMs: 0
  });

  // Modal dialogs
  const [isComfySettingsOpen, setIsComfySettingsOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isDccBridgeOpen, setIsDccBridgeOpen] = useState(false);

  // Generation & Execution states
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionProgress, setExecutionProgress] = useState(0);
  const [executionStep, setExecutionStep] = useState('');
  const [activeTask, setActiveTask] = useState<ComfyActiveTask | null>(null);

  const dismissActiveTask = useCallback(() => {
    setActiveTask(null);
  }, []);

  // 1. Generation tool state
  const [generationSettings, setGenerationSettings] = useState<GenerationSettings>({
    mode: 'image-to-3d',
    image: null,
    prompt: 'A stylized medieval fantasy goblin warrior holding two sharp daggers on circular stone pedestal',
    aiModel: 'hd',
    meshQuality: 'high',
    textureQuality: 'high',
    quadTopology: false,
    seed: 42891,
    guidanceScale: 7.5,
    removeBackground: true
  });

  // 2. Remesh tool state
  const [remeshSettings, setRemeshSettings] = useState<RemeshSettings>({
    tab: 'auto',
    preset: 'high',
    targetFaces: 48512,
    mode: 'adaptive',
    preserveShape: true,
    preserveSharpEdges: true,
    preserveUVs: false,
    detailPreservation: 0.75,
    boundaryProtection: 0.50,
    voxelSize: 0.10
  });

  // 3. Texture tool state
  const [textureSettings, setTextureSettings] = useState<TextureSettings>({
    workflow: 'texture',
    mode: 'ai',
    style: 'realistic',
    resolution: '4K',
    referenceImage: null,
    prompt: 'Weathered mechanical steampunk plating with rusted edges and glowing orange optics',
    maps: {
      albedo: true,
      normal: true,
      roughness: true,
      metallic: true,
      ao: true,
      height: false
    }
  });

  // 4. Animate tool state
  const [animateSettings, setAnimateSettings] = useState<AnimateSettings>({
    mode: 'animation',
    type: 'presets',
    prompt: 'Combat ready aggressive idle breathing and looking around with daggers',
    preset: 'idle',
    intensity: 1.0,
    speed: 1.0,
    loop: true
  });

  // 5. Rigging tool state
  const [riggingSettings, setRiggingSettings] = useState<RiggingSettings>({
    tab: 'rigging',
    rigType: 'humanoid',
    autoRig: true,
    bonesDetection: true,
    symmetry: true,
    boneSize: 1.0,
    boneCount: 32
  });

  const [segmentationSettings, setSegmentationSettings] = useState<SegmentationSettings>({
    mode: 'auto',
    target: 'character',
    selectedPart: 'Whole Character',
    feather: 0.15,
    preserveTextures: true
  });

  // Animation timeline state
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const totalFrames = 120;
  const fps = 30;

  const tracks: AnimationTrack[] = useMemo(() => [
    { id: 't_root', name: 'Root Motion', type: 'root', color: '#f5c518', keyframes: [{ frame: 0, value: 0 }, { frame: 30, value: 0.2 }, { frame: 60, value: 0 }, { frame: 90, value: -0.1 }, { frame: 120, value: 0 }] },
    { id: 't_hips', name: 'Hips / Pelvis', type: 'bone', color: '#60a5fa', keyframes: [{ frame: 0, value: 0 }, { frame: 30, value: 0.15 }, { frame: 60, value: 0 }, { frame: 90, value: 0.15 }, { frame: 120, value: 0 }] },
    { id: 't_spine', name: 'Spine & Chest', type: 'bone', color: '#34d399', keyframes: [{ frame: 0, value: 0 }, { frame: 45, value: 0.3 }, { frame: 75, value: -0.1 }, { frame: 120, value: 0 }] },
    { id: 't_arms', name: 'Upper Limbs (Arms)', type: 'bone', color: '#f472b6', keyframes: [{ frame: 0, value: 0 }, { frame: 30, value: 0.5 }, { frame: 60, value: 0 }, { frame: 90, value: -0.5 }, { frame: 120, value: 0 }] },
    { id: 't_legs', name: 'Lower Limbs (Legs)', type: 'bone', color: '#a78bfa', keyframes: [{ frame: 0, value: 0 }, { frame: 30, value: -0.4 }, { frame: 60, value: 0 }, { frame: 90, value: 0.4 }, { frame: 120, value: 0 }] }
  ], []);

  // Rigging bones
  const [bones, setBones] = useState<BoneNode[]>(DEFAULT_HUMANOID_SKELETON);
  const [selectedBoneId, setSelectedBoneId] = useState<string | null>('spine');

  // Active asset reference
  const currentAsset = useMemo(() => selectedAssetId ? (assets.find(a => a.id === selectedAssetId) ?? null) : null, [assets, selectedAssetId]);

  // Handle active tool switches & special view modes
  useEffect(() => {
    if (activeTool === 'rigging' || activeTool === 'animate') {
      setShowBones(true);
    } else {
      setShowBones(false);
    }
    if (activeTool === 'remesh') {
      setShowWireframe(true);
    }
  }, [activeTool]);

  const refreshHistory = useCallback(async () => {
    try {
      const history = await comfyClient.getHistory(64);
      const parsed: ModelAsset[] = [];
      const seen = new Set<string>();

      for (const [promptId, record] of Object.entries(history)) {
        const outputs = record.outputs ?? {};
        for (const [nodeId, nodeOutput] of Object.entries(outputs)) {
          if (!nodeOutput || typeof nodeOutput !== 'object') continue;
          for (const [key, raw] of Object.entries(nodeOutput)) {
            if (!Array.isArray(raw)) continue;
            for (const entry of raw) {
              if (!entry || typeof entry !== 'object') continue;
              const item = entry as Record<string, unknown>;
              const filename = typeof item.filename === 'string' ? item.filename : null;
              if (!filename) continue;
              const subfolder = typeof item.subfolder === 'string' ? item.subfolder : '';
              const type = typeof item.type === 'string' ? item.type : 'output';
              const formatFromName = filename.split('.').pop()?.toUpperCase() || 'FILE';
              const id = `${promptId}:${nodeId}:${key}:${filename}:${subfolder}`;
              if (seen.has(id)) continue;
              seen.add(id);
              const isImage = /^(png|jpg|jpeg|webp)$/i.test(formatFromName) || key.toLowerCase().includes('image');
              const format: ModelAsset['format'] = isImage ? 'IMAGE' : ['GLB','OBJ','PLY'].includes(formatFromName) ? formatFromName as ModelAsset['format'] : 'FILE';
              parsed.push({
                id,
                name: filename,
                category: isImage ? 'texture' : 'generation',
                thumbnail: isImage ? comfyClient.getViewUrl(filename, subfolder, type) : '',
                source: {
                  filename,
                  subfolder,
                  type,
                  viewUrl: comfyClient.getViewUrl(filename, subfolder, type),
                  promptId,
                  nodeId
                },
                meshType: 'custom',
                faces: 0,
                vertices: 0,
                triangles: 0,
                statsAvailable: false,
                topology: 'Triangle',
                format,
                dateCreated: '',
                tags: [isImage ? 'Image' : 'ComfyUI Output'],
                materials: []
              });
            }
          }
        }
      }

      setAssets(prev => {
        const local = prev.filter(asset => asset.source?.localUrl);
        const merged = [...parsed];
        for (const asset of local) if (!merged.some(a => a.id === asset.id)) merged.push(asset);
        setSelectedAssetId(current => current && merged.some(a => a.id === current)
          ? current
          : (parsed[0]?.id ?? local[0]?.id ?? null));
        return merged;
      });
    } catch {
      // Keep the last successful history snapshot; offline state comes from /system_stats.
    }
  }, []);

  // Periodic real stats fetch from ComfyUI backend
  const refreshComfyStats = useCallback(async () => {
    const stats = await comfyClient.getSystemStats();
    if (stats.status !== 'online') {
      setComfyStats(stats);
      return;
    }
    try {
      const queue = await comfyClient.getQueue();
      setComfyStats({
        ...stats,
        queueRunning: queue.running.length,
        queuePending: queue.pending.length
      });
    } catch {
      setComfyStats(stats);
    }
  }, []);

  useEffect(() => {
    void refreshComfyStats();
    void refreshHistory();
    const interval = setInterval(() => { void refreshComfyStats(); void refreshHistory(); }, 2000);
    const clientId = `nexus-${Date.now()}`;
    comfyClient.connectWebSocket(clientId);
    const offProgress = comfyClient.on('progress', (data) => {
      const payload = typeof data === 'object' && data !== null ? data as Record<string, unknown> : {};
      const max = Number(payload.max) || 0;
      const value = Number(payload.value) || 0;
      const node = typeof payload.node === 'string' ? payload.node : undefined;
      const progress = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
      setExecutionProgress(progress);
      setActiveTask(prev => prev ? { ...prev, status: 'running', progress, activeNode: node ?? prev.activeNode, currentStep: node ? `Executing ${node}` : prev.currentStep } : prev);
    });
    const offExecuting = comfyClient.on('executing', (data) => {
      const payload = typeof data === 'object' && data !== null ? data as Record<string, unknown> : {};
      const node = typeof payload.node === 'string' ? payload.node : undefined;
      setIsExecuting(Boolean(node));
      setExecutionStep(node ? `Executing ${node}` : '');
      setActiveTask(prev => prev ? { ...prev, status: node ? 'running' : 'completed', activeNode: node, currentStep: node ? `Executing ${node}` : 'Completed' } : prev);
    });
    const offExecuted = comfyClient.on('executed', (data) => {
      setIsExecuting(false);
      setComfyStats(prev => ({ ...prev, activePromptId: null }));
      setExecutionProgress(100);
      setExecutionStep('Completed');
      setActiveTask(prev => prev ? { ...prev, status: 'completed', progress: 100, activeNode: undefined, currentStep: 'Completed' } : prev);
      void refreshHistory();
    });

    const offError = comfyClient.on('execution_error', (data) => {
      const payload = typeof data === 'object' && data !== null ? data as Record<string, unknown> : {};
      const message = String(payload.exception_message || payload.message || 'ComfyUI execution error');
      setIsExecuting(false);
      setComfyStats(prev => ({ ...prev, activePromptId: null }));
      setExecutionProgress(0);
      setExecutionStep(message);
      setActiveTask(prev => prev ? { ...prev, status: 'failed', currentStep: message } : prev);
    });
    const offConnected = comfyClient.on('connected', refreshComfyStats);
    const offDisconnected = comfyClient.on('disconnected', refreshComfyStats);
    const onHistoryRefresh = () => { void refreshHistory(); };
    window.addEventListener('nexus:history-refresh', onHistoryRefresh);
    return () => {
      clearInterval(interval);
      offProgress();
      offExecuting();
      offError();
      offExecuted();
      offConnected();
      offDisconnected();
      window.removeEventListener('nexus:history-refresh', onHistoryRefresh);
      comfyClient.disconnectWebSocket();
    };
  }, [refreshComfyStats, refreshHistory]);

  // Asset selection
  const selectAsset = useCallback((id: string) => {
    setSelectedAssetId(id);
    const asset = assets.find(a => a.id === id);
    if (asset) {
      // Sync remesh faces counter
      setRemeshSettings(prev => ({
        ...prev,
        targetFaces: asset.faces
      }));
    }
  }, [assets]);

  const setCurrentAsset = useCallback((asset: ModelAsset) => {
    selectAsset(asset.id);
  }, [selectAsset]);

  const duplicateAsset = useCallback((id: string) => {
    const existing = assets.find(a => a.id === id);
    if (!existing) return;
    const duplicated: ModelAsset = {
      ...existing,
      id: `asset-${Date.now()}`,
      name: `${existing.name}_copy`,
      dateCreated: new Date().toISOString().split('T')[0]
    };
    setAssets(prev => [duplicated, ...prev]);
    setSelectedAssetId(duplicated.id);
  }, [assets]);

  // Property update helper
  const updateAssetProperties = useCallback((id: string, updates: Partial<ModelAsset>) => {
    setAssets(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
  }, []);

  // Material update helper
  const updateMaterialConfig = useCallback((updates: Partial<MaterialConfig>) => {
    if (!currentAsset) return;
    const currentMat = currentAsset.materialConfig || {
      roughness: 0.5,
      metalness: 0.5,
      color: '#888888',
      wireframe: false,
      wireframeColor: '#222222',
      normalScale: 1.0,
      aoIntensity: 0.8,
      style: 'realistic'
    };
    updateAssetProperties(currentAsset.id, {
      materialConfig: { ...currentMat, ...updates }
    });
  }, [currentAsset, updateAssetProperties]);

  const deleteAsset = useCallback((id: string) => {
    setAssets(prev => {
      const next = prev.filter(a => a.id !== id);
      if (id === selectedAssetId && next.length > 0) {
        setSelectedAssetId(next[0].id);
      }
      return next;
    });
  }, [selectedAssetId]);

  const addAsset = useCallback((asset: ModelAsset) => {
    setAssets(prev => [asset, ...prev]);
    setSelectedAssetId(asset.id);
  }, []);


  const updateBone = useCallback((id: string, updates: Partial<BoneNode>) => {
    setBones(prev => prev.map(b => b.id === id ? { ...b, ...updates } : b));
  }, []);

  const resetCamera = useCallback(() => {
    setViewportResetTrigger(prev => prev + 1);
  }, []);

  const fitToScreen = useCallback(() => {
    setViewportResetTrigger(prev => prev + 1);
  }, []);

  const cancelExecution = useCallback(() => {
    comfyClient.interrupt();
    setIsExecuting(false);
    setComfyStats(prev => ({ ...prev, activePromptId: null }));
    setExecutionProgress(0);
    setExecutionStep('');
    setActiveTask(prev => prev ? { ...prev, status: 'interrupted', currentStep: 'Execution cancelled by user' } : null);
    setComfyStats(prev => ({ ...prev, queueRunning: Math.max(0, prev.queueRunning - 1), activePromptId: null }));
  }, []);

  const startTask = useCallback((type: ComfyActiveTask['type'], title: string, promptId?: string) => {
    setIsExecuting(true);
    setComfyStats(prev => ({ ...prev, activePromptId: promptId ?? null }));
    setExecutionProgress(0);
    setExecutionStep('Queued in ComfyUI');
    setActiveTask({
      id: promptId ?? `task-${type}-${Date.now()}`,
      type,
      title,
      startedAt: Date.now(),
      status: 'queued',
      progress: 0,
      currentStep: 'Queued in ComfyUI'
    });
  }, []);

  const queueWorkflow = useCallback(async (
    type: ComfyActiveTask['type'],
    title: string,
    workflow: Record<string, unknown>
  ) => {
    if (comfyStats.status !== 'online') {
      setExecutionStep('ComfyUI backend is offline.');
      return;
    }
    const result = await comfyClient.queuePrompt(workflow, `nexus-ui-${crypto.randomUUID()}`);
    if (result.error || !result.prompt_id) {
      setExecutionStep(result.error || 'ComfyUI rejected the workflow.');
      setActiveTask({
        id: `task-${type}-${Date.now()}`,
        type,
        title,
        startedAt: Date.now(),
        status: 'failed',
        progress: 0,
        currentStep: result.error || 'ComfyUI rejected the workflow.'
      });
      return;
    }
    startTask(type, title, result.prompt_id);
  }, [comfyStats.status, startTask]);

  const generateTextTo3D = useCallback(async (customPrompt?: string) => {
    const promptToUse = (customPrompt ?? generationSettings.prompt).trim();
    if (!promptToUse) {
      setExecutionStep('Enter a text prompt before queueing a workflow.');
      return;
    }
    setExecutionStep('Choose/load a real ComfyUI workflow in the Nodes page; no fake workflow is submitted.');
    setActiveTask({
      id: `task-text-to-3d-${Date.now()}`,
      type: 'text-to-3d',
      title: 'Text-to-3D generation',
      startedAt: Date.now(),
      status: 'failed',
      progress: 0,
      currentStep: 'No concrete ComfyUI workflow template is configured.'
    });
  }, [generationSettings.prompt]);

  const generateImageTo3D = useCallback(async (customImage?: string) => {
    if (!customImage && !generationSettings.image) {
      setExecutionStep('Upload an image before queueing a workflow.');
      return;
    }
    setExecutionStep('Choose/load a real ComfyUI workflow in the Nodes page; no fake workflow is submitted.');
    setActiveTask({
      id: `task-image-to-3d-${Date.now()}`,
      type: 'image-to-3d',
      title: 'Image-to-3D generation',
      startedAt: Date.now(),
      status: 'failed',
      progress: 0,
      currentStep: 'No concrete ComfyUI workflow template is configured.'
    });
  }, [generationSettings.image]);

  const generate3DModel = useCallback(async () => {
    if (generationSettings.mode === 'text-to-3d') return generateTextTo3D();
    return generateImageTo3D();
  }, [generationSettings.mode, generateTextTo3D, generateImageTo3D]);

  const runModelGeneration = generate3DModel;

  const unavailableTool = useCallback(async (tool: ComfyActiveTask['type'], title: string) => {
    setExecutionStep('Choose/load a real ComfyUI workflow in the Nodes page; no fake workflow is submitted.');
    setActiveTask({
      id: `task-${tool}-${Date.now()}`,
      type: tool,
      title,
      startedAt: Date.now(),
      status: 'failed',
      progress: 0,
      currentStep: 'No concrete ComfyUI workflow template is configured.'
    });
  }, []);

  const runRemeshGeneration = useCallback(async () => unavailableTool('retopo', 'Remesh / retopology'), [unavailableTool]);
  const runTextureGeneration = useCallback(async () => unavailableTool('texture', 'Texture generation'), [unavailableTool]);
  const runAnimateGeneration = useCallback(async () => unavailableTool('animate', 'Animation generation'), [unavailableTool]);
  const runRiggingGeneration = useCallback(async () => unavailableTool('rigging', 'Rigging generation'), [unavailableTool]);
  const runSegmentationGeneration = useCallback(async () => unavailableTool('segment', 'Segmentation'), [unavailableTool]);


  return (
    <WorkspaceContext.Provider
      value={{
        activeTool,
        setActiveTool,
        mainNav,
        setMainNav,
        assets,
        selectedAssetId,
        currentAsset,
        selectAsset,
        updateAssetProperties,
        updateMaterialConfig,
        deleteAsset,
        addAsset,
        shadingMode,
        setShadingMode,
        showWireframe,
        setShowWireframe,
        showGrid,
        setShowGrid,
        showBones,
        setShowBones,
        isTurntable,
        setIsTurntable,
        activeTransformTool,
        setActiveTransformTool,
        viewportResetTrigger,
        resetCamera,
        fitToScreen,
        activeRightTab,
        setActiveRightTab,
        rightPanelMode: activeRightTab,
        setRightPanelMode: setActiveRightTab,
        isLeftPanelOpen,
        setIsLeftPanelOpen,
        toolPanelOpen: isLeftPanelOpen,
        setToolPanelOpen: setIsLeftPanelOpen,
        isRightPanelOpen,
        setIsRightPanelOpen,
        rightPanelOpen: isRightPanelOpen,
        setRightPanelOpen: setIsRightPanelOpen,
        setCurrentAsset,
        assetFilter,
        setAssetFilter,
        duplicateAsset,
        comfyStats,
        isComfySettingsOpen,
        setIsComfySettingsOpen,
        isExportModalOpen,
        setIsExportModalOpen,
        isDccBridgeOpen,
        setIsDccBridgeOpen,
        refreshComfyStats,
        activeTask,
        dismissActiveTask,
        isExecuting,
        executionProgress,
        executionStep,
        cancelExecution,
        generationSettings,
        setGenerationSettings,
        remeshSettings,
        setRemeshSettings,
        textureSettings,
        setTextureSettings,
        animateSettings,
        setAnimateSettings,
        riggingSettings,
        setRiggingSettings,
        segmentationSettings,
        setSegmentationSettings,
        bones,
        selectedBoneId,
        setSelectedBoneId,
        updateBone,
        currentFrame,
        setCurrentFrame,
        isPlaying,
        setIsPlaying,
        totalFrames,
        fps,
        tracks,
        generate3DModel,
        generateTextTo3D,
        generateImageTo3D,
        runModelGeneration,
        runRemeshGeneration,
        runTextureGeneration,
        runAnimateGeneration,
        runRiggingGeneration,
        runSegmentationGeneration,
        queueComfyWorkflow: (workflow, type, title) => queueWorkflow(type, title, workflow)
      }}
    >
      {children}
    </WorkspaceContext.Provider>
  );
};

export const useWorkspace = () => {
  const context = useContext(WorkspaceContext);
  if (!context) {
    throw new Error('useWorkspace must be used within a WorkspaceProvider');
  }
  return context;
};
