import { ComfySystemStats, ComfyNodeDef } from '../types';

export interface ComfyQueueItem {
  promptId: string;
  number: number;
  workflow: Record<string, unknown>;
  extraData?: Record<string, unknown>;
  outputs?: string[];
}

export interface ComfyQueueResponse {
  running: Array<[number, string, Record<string, unknown>, Record<string, unknown>, string[]]>;
  pending: Array<[number, string, Record<string, unknown>, Record<string, unknown>, string[]]>;
}

export interface ComfyOutputRef {
  filename: string;
  subfolder?: string;
  type?: string;
  format?: string;
}

export interface ComfyHistoryOutput {

  images?: Array<{ filename: string; subfolder: string; type: string }>;
  meshes?: Array<{ filename: string; format: string; subfolder?: string }>;
  gifs?: Array<{ filename: string; subfolder: string; type: string }>;
}

export interface ComfyHistoryItem {
  prompt?: [number, string, Record<string, unknown>, Record<string, unknown>, string[]];
  outputs?: Record<string, Record<string, unknown>>;
  status?: { status_str?: string; completed?: boolean; messages?: unknown[] };
}

export interface ComfyPromptPayload {
  prompt: Record<string, {
    inputs: Record<string, unknown>;
    class_type: string;
    _meta?: { title?: string };
  }>;
  client_id?: string;
  extra_data?: Record<string, unknown>;
}

export interface ComfyExecuteEvent {
  node: string | null;
  prompt_id: string;
  output?: Record<string, unknown>;
}

export interface ComfyProgressEvent {
  value: number;
  max: number;
  node: string;
  prompt_id: string;
}

export interface ComfyObjectInfoNode {
  input?: {
    required?: Record<string, [string, unknown] | [unknown[]]>;
    optional?: Record<string, [string, unknown] | [unknown[]]>;
  };
  output: string[];
  output_is_list?: boolean[];
  output_name?: string[];
  name: string;
  display_name?: string;
  description?: string;
  category?: string;
  output_node?: boolean;
}

export type ComfyObjectInfoResponse = Record<string, ComfyObjectInfoNode>;

/**
 * Official ComfyUI & ComfyUI-3D-Pack Frontend API Client
 * Compatible with standard ComfyUI REST + WebSocket protocol (default port 8188)
 */
export class ComfyApiClient {
  private baseUrl: string;
  private wsUrl: string;
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<(data: unknown) => void>> = new Map();
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(host = 'http://127.0.0.1:8188') {
    const persisted = typeof window !== 'undefined' ? window.localStorage.getItem('nexus-comfy-host') : null;
    this.baseUrl = (persisted || host).replace(/\/$/, '');
    this.wsUrl = this.baseUrl.replace(/^http/, 'ws') + '/ws';
  }

  public setHost(host: string) {
    this.baseUrl = host.replace(/\/$/, '');
    if (typeof window !== 'undefined') window.localStorage.setItem('nexus-comfy-host', this.baseUrl);
    this.wsUrl = this.baseUrl.replace(/^http/, 'ws') + '/ws';
    this.disconnectWebSocket();
    this.connectWebSocket();
  }

  public setBaseUrl(host: string) {
    this.setHost(host);
  }

  public getHost(): string {
    return this.baseUrl;
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  public async ping(): Promise<boolean> {
    try {
      const res = await fetch(`${this.baseUrl}/system_stats`, {
        method: 'GET',
        signal: AbortSignal.timeout(2500)
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  /**
   * Check connection and fetch real system stats
   * GET /system_stats
   */
  public async getSystemStats(): Promise<ComfySystemStats> {
    const start = performance.now();
    const base = this.baseUrl;
    try {
      const response = await fetch(`${base}/system_stats`, {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(4000)
      });
      const latency = Math.round(performance.now() - start);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json() as Record<string, unknown>;
      const system = (data.system ?? {}) as Record<string, unknown>;
      const devices = Array.isArray(data.devices) ? data.devices : [];
      const device = (devices[0] ?? {}) as Record<string, unknown>;

      const asNumber = (value: unknown): number | null => {
        const n = Number(value);
        return Number.isFinite(n) ? n : null;
      };
      const bytesToGb = (value: unknown): number | null => {
        const n = asNumber(value);
        return n == null ? null : Number((n / (1024 ** 3)).toFixed(2));
      };

      const vramTotalGb = bytesToGb(device.vram_total);
      const vramFreeGb = bytesToGb(device.vram_free);
      const torchTotalGb = bytesToGb(device.torch_vram_total);
      const torchFreeGb = bytesToGb(device.torch_vram_free);
      const ramTotalGb = bytesToGb(system.ram_total);
      const ramFreeGb = bytesToGb(system.ram_free);

      return {
        status: 'online',
        host: base,
        gpu: typeof device.name === 'string' ? device.name : 'Unavailable',
        vramUsedGb: vramTotalGb != null && vramFreeGb != null ? Number((vramTotalGb - vramFreeGb).toFixed(2)) : null,
        vramTotalGb,
        ramUsedGb: ramTotalGb != null && ramFreeGb != null ? Number((ramTotalGb - ramFreeGb).toFixed(2)) : null,
        ramTotalGb,
        torchVramUsedGb: torchTotalGb != null && torchFreeGb != null ? Number((torchTotalGb - torchFreeGb).toFixed(2)) : null,
        torchVramTotalGb: torchTotalGb,
        gpuType: typeof device.type === 'string' ? device.type : null,
        gpuIndex: asNumber(device.index),
        pythonVersion: typeof system.python_version === 'string' ? system.python_version : null,
        torchVersion: typeof system.pytorch_version === 'string' ? system.pytorch_version : null,
        comfyVersion: typeof system.comfyui_version === 'string' ? system.comfyui_version : null,
        pack3dVersion: null,
        queueRunning: asNumber(data.queue_running) ?? 0,
        queuePending: asNumber(data.queue_pending) ?? 0,
        activePromptId: null,
        activeNode: null,
        lastPingMs: latency
      };
    } catch (error) {
      return {
        status: 'offline',
        host: base,
        gpu: 'Unavailable',
        vramUsedGb: null,
        vramTotalGb: null,
        ramUsedGb: null,
        ramTotalGb: null,
        torchVramUsedGb: null,
        torchVramTotalGb: null,
        gpuType: null,
        gpuIndex: null,
        pythonVersion: null,
        torchVersion: null,
        comfyVersion: null,
        pack3dVersion: null,
        queueRunning: 0,
        queuePending: 0,
        activePromptId: null,
        activeNode: null,
        lastPingMs: 0
      };
    }
  }

  /**
   * Fetch real registered node definitions
   * GET /object_info
   */
  public async getObjectInfo(): Promise<ComfyObjectInfoResponse> {
    const response = await fetch(`${this.baseUrl}/object_info`, {
      signal: AbortSignal.timeout(5000),
      headers: { 'Accept': 'application/json' }
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const data: unknown = await response.json();
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid /object_info response');
    }
    return data as ComfyObjectInfoResponse;
  }

  /**
   * Normalized Node Definitions List
   */
  public async getNodeDefinitionsList(): Promise<ComfyNodeDef[]> {
    const raw = await this.getObjectInfo();
    const list: ComfyNodeDef[] = [];

    for (const [nodeId, rawNodeValue] of Object.entries(raw)) {
      if (!rawNodeValue || typeof rawNodeValue !== 'object') continue;
      const rawNode = rawNodeValue as ComfyObjectInfoNode;
      const inputs: ComfyNodeDef['inputs'] = [];

      for (const [sectionName, section] of [
        ['required', rawNode.input?.required],
        ['optional', rawNode.input?.optional]
      ] as const) {
        if (!section) continue;
        for (const [name, spec] of Object.entries(section)) {
          const tuple = Array.isArray(spec) ? spec : [];
          const first = tuple[0];
          const config = (tuple[1] && typeof tuple[1] === 'object')
            ? tuple[1] as Record<string, unknown>
            : {};
          const comboOptions = Array.isArray(first) ? first : null;
          const firstString = typeof first === 'string' ? first : 'ANY';
          const type = comboOptions ? 'COMBO' : firstString;
          const defaultValue = 'default' in config ? config.default : (comboOptions ? comboOptions[0] : undefined);
          const min = typeof config.min === 'number' ? config.min : undefined;
          const max = typeof config.max === 'number' ? config.max : undefined;
          const step = typeof config.step === 'number' ? config.step : undefined;
          const multiline = config.multiline === true;
          const forceInput = config.forceInput === true;

          inputs.push({
            name,
            type,
            required: sectionName === 'required',
            default: defaultValue,
            options: comboOptions ? comboOptions.map(value => String(value)) : undefined,
            min,
            max,
            step,
            multiline,
            forceInput,
            raw: spec
          });
        }
      }

      const outputs = (rawNode.output || []).map((outType, index) => ({
        name: rawNode.output_name?.[index] || `output_${index}`,
        type: outType
      }));

      list.push({
        id: nodeId,
        name: nodeId,
        displayName: rawNode.display_name || nodeId,
        category: rawNode.category || 'general',
        description: rawNode.description || '',
        inputs,
        outputs,
        outputNode: rawNode.output_node === true
      });
    }

    return list.sort((a, b) => `${a.category}:${a.displayName || a.name}`.localeCompare(`${b.category}:${b.displayName || b.name}`));
  }

  /**
   * Fetch current queue status
   * GET /queue
   */
  public async getQueue(): Promise<{ running: ComfyQueueResponse['running']; pending: ComfyQueueResponse['pending'] }> {
    const res = await fetch(`${this.baseUrl}/queue`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json() as { queue_running?: ComfyQueueResponse['running']; queue_pending?: ComfyQueueResponse['pending'] };
    return { running: json.queue_running || [], pending: json.queue_pending || [] };
  }

  /**
   * Fetch execution history
   * GET /history
   */
  public async getHistory(maxItems = 20): Promise<Record<string, ComfyHistoryItem>> {
    const res = await fetch(`${this.baseUrl}/history?max_items=${maxItems}`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json() as Record<string, ComfyHistoryItem>;
  }

  public async getViewBlob(ref: ComfyOutputRef): Promise<Blob> {
    const response = await fetch(
      this.getViewUrl(ref.filename, ref.subfolder ?? '', ref.type ?? 'output'),
      { signal: AbortSignal.timeout(15000) }
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.blob();
  }

  /**
   * Delete a prompt record from ComfyUI history.
   * POST /history { delete: [promptId] }
   */
  public async deleteHistory(promptId: string): Promise<void> {
    const res = await fetch(`${this.baseUrl}/history`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ delete: [promptId] })
    });
    if (!res.ok) {
      const message = await res.text();
      throw new Error(message || `HTTP ${res.status}`);
    }
  }

  /**
   * Queue workflow prompt for execution
   * POST /prompt
   */
  public async queuePrompt(promptWorkflow: Record<string, unknown>, clientId = 'nexus-ui'): Promise<{ prompt_id?: string; number?: number; error?: string }> {
    try {
      const res = await fetch(`${this.baseUrl}/prompt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptWorkflow,
          client_id: clientId
        })
      });
      if (res.ok) {
        return await res.json();
      }
      const errText = await res.text();
      return { error: errText || `Error HTTP ${res.status}` };
    } catch (e) {
      return { error: e instanceof Error ? e.message : 'Connection failed to ComfyUI backend' };
    }
  }

  /**
   * Interrupt current execution
   * POST /interrupt
   */
  public async interrupt(): Promise<boolean> {
    try {
      const res = await fetch(`${this.baseUrl}/interrupt`, { method: 'POST' });
      return res.ok;
    } catch {
      return false;
    }
  }

  /**
   * Upload image to ComfyUI input folder
   * POST /upload/image
   */
  public async uploadImage(file: File): Promise<{ name: string; subfolder: string; type: string }> {
    const formData = new FormData();
    formData.append('image', file);
    formData.append('overwrite', 'true');
    const res = await fetch(`${this.baseUrl}/upload/image`, {
      method: 'POST',
      body: formData
    });
    if (!res.ok) {
      const message = await res.text();
      throw new Error(message || `HTTP ${res.status}`);
    }
    return await res.json() as { name: string; subfolder: string; type: string };
  }

  /**
   * Upload 3D mesh (OBJ, GLB, STL) to ComfyUI input folder
   */
  public async uploadMesh(_file: File): Promise<never> {
    throw new Error('Generic mesh upload is not a standard ComfyUI endpoint; use the installed custom-node input contract.');
  }

  /**
   * Get generated view URL
   */
  public getViewUrl(filename: string, subfolder = '', type = 'output'): string {
    return `${this.baseUrl}/view?filename=${encodeURIComponent(filename)}&subfolder=${encodeURIComponent(subfolder)}&type=${type}`;
  }

  /**
   * WebSocket client for real-time node execution progress & status
   */
  public connectWebSocket(clientId = 'nexus-ui') {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    try {
      this.ws = new WebSocket(`${this.wsUrl}?clientId=${clientId}`);

      this.ws.onopen = () => {
        this.emit('connected', { status: 'online' });
      };

      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          const { type, data } = message;

          if (type) {
            this.emit(type, data);
          }
        } catch {
          // Binary preview or non-JSON message
        }
      };

      this.ws.onclose = () => {
        this.emit('disconnected', { status: 'offline' });
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => {
          this.connectWebSocket(clientId);
        }, 5000);
      };

      this.ws.onerror = () => {
        this.emit('error', { error: 'WebSocket connection failed' });
      };
    } catch {
      // Offline mode
    }
  }

  public disconnectWebSocket() {
    clearTimeout(this.reconnectTimer);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  public on(event: string, callback: (data: unknown) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => this.off(event, callback);
  }

  public off(event: string, callback: (data: unknown) => void) {
    this.listeners.get(event)?.delete(callback);
  }

  private emit(event: string, data: unknown) {
    this.listeners.get(event)?.forEach(cb => {
      try {
        cb(data);
      } catch (err) {
        console.error(`Error in ComfyUI event listener for ${event}:`, err);
      }
    });
  }
}

export const comfyClient = new ComfyApiClient();

// Standalone Service Fetchers for direct module consumption
export async function fetchObjectInfo(host?: string): Promise<ComfyObjectInfoResponse> {
  const client = host ? new ComfyApiClient(host) : comfyClient;
  return client.getObjectInfo();
}

export async function fetchNodeDefinitions(host?: string): Promise<ComfyNodeDef[]> {
  const client = host ? new ComfyApiClient(host) : comfyClient;
  return client.getNodeDefinitionsList();
}

export async function fetchSystemStats(host?: string): Promise<ComfySystemStats> {
  const client = host ? new ComfyApiClient(host) : comfyClient;
  return client.getSystemStats();
}

export async function fetchQueue(host?: string): Promise<{ running: ComfyQueueResponse['running']; pending: ComfyQueueResponse['pending'] }> {
  const client = host ? new ComfyApiClient(host) : comfyClient;
  return client.getQueue();
}

export async function fetchHistory(host?: string, maxItems = 20): Promise<Record<string, ComfyHistoryItem>> {
  const client = host ? new ComfyApiClient(host) : comfyClient;
  return client.getHistory(maxItems);
}
