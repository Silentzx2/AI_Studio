import React, { useState } from 'react';
import { 
  Sliders, 
  Download, 
  Layers, 
  Box, 
  Rotate3d, 
  Maximize2, 
  Move, 
  Check,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Palette,
  Activity,
  GitBranch,
  Eye,
  RefreshCw,
  Lock,
  Unlock,
  Hexagon,
  FileCode,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { useWorkspace } from '../../store/WorkspaceContext';
import { ShadingMode } from '../../types';

export const RightPropertyPanel: React.FC = () => {
  const { 
    currentAsset, 
    activeTool, 
    shadingMode, 
    setShadingMode,
    showWireframe,
    setShowWireframe,
    remeshSettings,
    textureSettings,
    generationSettings,
    animateSettings,
    totalFrames,
    fps,
    bones,
    comfyStats
  } = useWorkspace();

  const [exportFormat, setExportFormat] = useState<'glb' | 'obj' | 'fbx' | 'usdz' | 'stl'>('glb');
  const [embedTextures, setEmbedTextures] = useState(true);
  const [dracoCompression, setDracoCompression] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  // 3D Object Transform States
  const [transform, setTransform] = useState({
    posX: 0,
    posY: 0,
    posZ: 0,
    rotX: 0,
    rotY: 0,
    rotZ: 0,
    scaleX: 1.0,
    scaleY: 1.0,
    scaleZ: 1.0,
    lockScale: true
  });

  // Material & PBR Shader Settings
  const [materialSettings, setMaterialSettings] = useState({
    albedoColor: '#ffffff',
    roughness: 0.45,
    metallic: 0.15,
    normalStrength: 1.0,
    ambientOcclusion: 0.85,
    displacementScale: 0.05,
    normalFormat: 'OpenGL' as 'OpenGL' | 'DirectX',
    uvProjection: 'Smart UV (xatlas)'
  });

  const handleScaleChange = (val: number) => {
    if (transform.lockScale) {
      setTransform(prev => ({ ...prev, scaleX: val, scaleY: val, scaleZ: val }));
    } else {
      setTransform(prev => ({ ...prev, scaleX: val }));
    }
  };

  const handleResetTransform = () => {
    setTransform({
      posX: 0,
      posY: 0,
      posZ: 0,
      rotX: 0,
      rotY: 0,
      rotZ: 0,
      scaleX: 1.0,
      scaleY: 1.0,
      scaleZ: 1.0,
      lockScale: true
    });
  };

  const handleExportDownload = async () => {
    if (!currentAsset?.source) return;
    setIsExporting(true);
    try {
      if (currentAsset.source.localUrl) {
        const link = document.createElement('a');
        link.href = currentAsset.source.localUrl;
        link.download = `${currentAsset.name}.${exportFormat}`;
        link.click();
      } else if (currentAsset.source.viewUrl) {
        const response = await fetch(currentAsset.source.viewUrl);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = currentAsset.name;
        link.click();
        URL.revokeObjectURL(url);
      } else {
        throw new Error('Selected asset has no downloadable source.');
      }
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (error) {
      console.error(error);
      setExportSuccess(false);
    } finally {
      setIsExporting(false);
    }
  };



  if (!currentAsset) {
    return (
      <div id="panel-properties-inspector" className="flex h-full items-center justify-center bg-[#101115] px-6 text-center">
        <div>
          <Box className="w-8 h-8 mx-auto mb-3 text-[#3d4350]" />
          <div className="text-xs font-semibold text-[#9ca3af]">No asset selected</div>
          <div className="text-[10px] text-[#626977] mt-1">Generate or import a real asset to inspect its properties.</div>
        </div>
      </div>
    );
  }


  return (
    <div 
      id="panel-properties-inspector" 
      className="flex flex-col h-full bg-[#101115] text-xs select-none overflow-y-auto"
    >
      {/* Header with Asset Meta */}
      <div className="p-3 border-b border-[#21242c] flex items-center justify-between">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-6 h-6 rounded-lg bg-[#1c202a] border border-[#2d3240] flex items-center justify-center text-[#f5c518] flex-shrink-0">
            <Sliders className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <h2 className="font-bold text-xs text-[#f3f4f6] truncate">{currentAsset.name}</h2>
            <span className="text-[10px] text-[#717786] block">Inspector & Properties</span>
          </div>
        </div>
        <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-md bg-[#1d212b] border border-[#2c3240] text-[#f5c518] flex-shrink-0">
          {currentAsset.format}
        </span>
      </div>

      <div className="p-3 space-y-4">
        {/* 1. Object Transform Section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
              <Move className="w-3.5 h-3.5 text-[#f5c518]" />
              Object Transform
            </span>
            <button
              onClick={handleResetTransform}
              title="Reset Transform"
              className="p-1 rounded text-[#717786] hover:text-[#f3f4f6] hover:bg-[#181a22] transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>

          {/* Position (m) */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-[#9ca3af]">
              <span>Position (m)</span>
              <span className="font-mono text-[#606775]">World Space</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#ef4444] font-bold mr-1 text-[10px]">X</span>
                <input 
                  type="number" 
                  step="0.1" 
                  value={transform.posX} 
                  onChange={(e) => setTransform(p => ({ ...p, posX: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent text-[#e5e7eb] outline-none" 
                />
              </div>
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#22c55e] font-bold mr-1 text-[10px]">Y</span>
                <input 
                  type="number" 
                  step="0.1" 
                  value={transform.posY} 
                  onChange={(e) => setTransform(p => ({ ...p, posY: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent text-[#e5e7eb] outline-none" 
                />
              </div>
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#3b82f6] font-bold mr-1 text-[10px]">Z</span>
                <input 
                  type="number" 
                  step="0.1" 
                  value={transform.posZ} 
                  onChange={(e) => setTransform(p => ({ ...p, posZ: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent text-[#e5e7eb] outline-none" 
                />
              </div>
            </div>
          </div>

          {/* Rotation (°) */}
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-[#9ca3af]">
              <span>Rotation (Euler °)</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#ef4444] font-bold mr-1 text-[10px]">X</span>
                <input 
                  type="number" 
                  value={transform.rotX} 
                  onChange={(e) => setTransform(p => ({ ...p, rotX: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent text-[#e5e7eb] outline-none" 
                />
              </div>
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#22c55e] font-bold mr-1 text-[10px]">Y</span>
                <input 
                  type="number" 
                  value={transform.rotY} 
                  onChange={(e) => setTransform(p => ({ ...p, rotY: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent text-[#e5e7eb] outline-none" 
                />
              </div>
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#3b82f6] font-bold mr-1 text-[10px]">Z</span>
                <input 
                  type="number" 
                  value={transform.rotZ} 
                  onChange={(e) => setTransform(p => ({ ...p, rotZ: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent text-[#e5e7eb] outline-none" 
                />
              </div>
            </div>
          </div>

          {/* Scale */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[10px] text-[#9ca3af]">
              <span>Scale Ratio</span>
              <button
                onClick={() => setTransform(p => ({ ...p, lockScale: !p.lockScale }))}
                className="flex items-center gap-1 text-[#f5c518] hover:underline text-[9px]"
              >
                {transform.lockScale ? <Lock className="w-2.5 h-2.5" /> : <Unlock className="w-2.5 h-2.5" />}
                <span>{transform.lockScale ? 'Uniform Locked' : 'Independent'}</span>
              </button>
            </div>
            <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#ef4444] font-bold mr-1 text-[10px]">X</span>
                <input 
                  type="number" 
                  step="0.05"
                  value={transform.scaleX} 
                  onChange={(e) => handleScaleChange(parseFloat(e.target.value) || 1)}
                  className="w-full bg-transparent text-[#e5e7eb] outline-none" 
                />
              </div>
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#22c55e] font-bold mr-1 text-[10px]">Y</span>
                <input 
                  type="number" 
                  step="0.05"
                  value={transform.scaleY} 
                  onChange={(e) => setTransform(p => ({ ...p, scaleY: parseFloat(e.target.value) || 1 }))}
                  disabled={transform.lockScale}
                  className={`w-full bg-transparent text-[#e5e7eb] outline-none ${transform.lockScale ? 'opacity-70' : ''}`} 
                />
              </div>
              <div className="flex items-center px-2 py-1 rounded-lg bg-[#15171e] border border-[#242834]">
                <span className="text-[#3b82f6] font-bold mr-1 text-[10px]">Z</span>
                <input 
                  type="number" 
                  step="0.05"
                  value={transform.scaleZ} 
                  onChange={(e) => setTransform(p => ({ ...p, scaleZ: parseFloat(e.target.value) || 1 }))}
                  disabled={transform.lockScale}
                  className={`w-full bg-transparent text-[#e5e7eb] outline-none ${transform.lockScale ? 'opacity-70' : ''}`} 
                />
              </div>
            </div>
          </div>
        </div>

        {/* 2. Geometry Statistics & Topology Health */}
        <div className="p-3 rounded-xl bg-[#13151b] border border-[#222632] space-y-2.5">
          <div className="flex items-center justify-between text-[#cbd5e1] font-semibold">
            <span className="flex items-center gap-1.5 text-[11px]">
              <Box className="w-3.5 h-3.5 text-[#f5c518]" />
              Geometry Topology
            </span>
            <span className="flex items-center gap-1 text-[9px] text-[#22c55e] font-mono px-1.5 py-0.5 rounded bg-[#22c55e]/10 border border-[#22c55e]/30">
              <ShieldCheck className="w-2.5 h-2.5" />
              Manifold OK
            </span>
          </div>

          <div className="grid grid-cols-3 gap-1.5 font-mono text-[10px]">
            <div className="p-2 rounded-lg bg-[#181a22] border border-[#272b38]">
              <span className="text-[#717786] block text-[9px]">Vertices</span>
              <span className="font-bold text-[#e5e7eb]">{currentAsset.statsAvailable ? currentAsset.vertices.toLocaleString() : '—'}</span>
            </div>
            <div className="p-2 rounded-lg bg-[#181a22] border border-[#272b38]">
              <span className="text-[#717786] block text-[9px]">Polygons</span>
              <span className="font-bold text-[#f5c518]">{currentAsset.statsAvailable ? currentAsset.faces.toLocaleString() : '—'}</span>
            </div>
            <div className="p-2 rounded-lg bg-[#181a22] border border-[#272b38]">
              <span className="text-[#717786] block text-[9px]">Topology</span>
              <span className="font-bold text-[#38bdf8] truncate block">{currentAsset.topology}</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[10px] text-[#8e95a5] pt-1 border-t border-[#1d202a]">
            <span>UV Channels</span>
            <span className="font-mono text-[#cbd5e1]">2 (UV0: Diffuse, UV1: Lightmap)</span>
          </div>
        </div>

        {/* 3. Dynamic Context-Aware Inspector Sections based on activeTool */}
        
        {/* CASE A: Tool is Texture or PBR */}
        {(activeTool === 'texture' || activeTool === 'pbr') && (
          <div className="space-y-3 p-3 rounded-xl bg-[#13151b] border border-[#222632]">
            <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-[#f5c518]" />
              PBR Material Channels
            </span>

            {/* Roughness */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-[#cbd5e1]">
                <span>Roughness</span>
                <span className="font-mono text-[#f5c518]">{materialSettings.roughness.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.02"
                value={materialSettings.roughness}
                onChange={(e) => setMaterialSettings(p => ({ ...p, roughness: parseFloat(e.target.value) }))}
                className="w-full accent-[#f5c518]"
              />
            </div>

            {/* Metallic */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-[#cbd5e1]">
                <span>Metallic</span>
                <span className="font-mono text-[#f5c518]">{materialSettings.metallic.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.02"
                value={materialSettings.metallic}
                onChange={(e) => setMaterialSettings(p => ({ ...p, metallic: parseFloat(e.target.value) }))}
                className="w-full accent-[#f5c518]"
              />
            </div>

            {/* Normal Strength */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-[#cbd5e1]">
                <span>Normal Intensity</span>
                <span className="font-mono text-[#f5c518]">{materialSettings.normalStrength.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0"
                max="3"
                step="0.1"
                value={materialSettings.normalStrength}
                onChange={(e) => setMaterialSettings(p => ({ ...p, normalStrength: parseFloat(e.target.value) }))}
                className="w-full accent-[#f5c518]"
              />
            </div>

            {/* Ambient Occlusion */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-[#cbd5e1]">
                <span>Cavity & AO Strength</span>
                <span className="font-mono text-[#f5c518]">{materialSettings.ambientOcclusion.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={materialSettings.ambientOcclusion}
                onChange={(e) => setMaterialSettings(p => ({ ...p, ambientOcclusion: parseFloat(e.target.value) }))}
                className="w-full accent-[#f5c518]"
              />
            </div>

            <div className="flex items-center justify-between text-[10px] text-[#8e95a5] pt-1.5 border-t border-[#1e222d]">
              <span>Normal Standard</span>
              <div className="flex gap-1">
                {(['OpenGL', 'DirectX'] as const).map(fmt => (
                  <button
                    key={fmt}
                    onClick={() => setMaterialSettings(p => ({ ...p, normalFormat: fmt }))}
                    className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                      materialSettings.normalFormat === fmt
                        ? 'bg-[#f5c518] text-[#111216]'
                        : 'bg-[#1a1d26] text-[#8e95a5] hover:text-[#f3f4f6]'
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* CASE B: Tool is Retopo / Remesh */}
        {(activeTool === 'remesh' || activeTool === 'retopo') && (
          <div className="space-y-3 p-3 rounded-xl bg-[#13151b] border border-[#222632]">
            <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
              <Hexagon className="w-3.5 h-3.5 text-[#f5c518]" />
              Quad Retopology Inspector
            </span>

            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Target Polycount</span>
                <span className="font-mono font-bold text-[#f5c518]">{remeshSettings.targetFaces.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Topology Mode</span>
                <span className="font-mono text-[#38bdf8] uppercase">{remeshSettings.retopologyMode}</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Symmetry Axis</span>
                <span className="font-mono text-[#cbd5e1] uppercase">{remeshSettings.symmetryAxis}</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Quad Flow Alignment</span>
                <span className="font-mono text-[#22c55e]">{currentAsset.topology} • {currentAsset.statsAvailable ? currentAsset.faces.toLocaleString() : '—'} faces</span>
              </div>
            </div>
          </div>
        )}

        {/* CASE C: Tool is Animate */}
        {activeTool === 'animate' && (
          <div className="space-y-3 p-3 rounded-xl bg-[#13151b] border border-[#222632]">
            <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-[#f5c518]" />
              Skeletal Rig & Motion
            </span>

            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Skeleton Hierarchy</span>
                <span className="font-mono text-[#f5c518]">{bones.length} bones in local rig state</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Motion Preset</span>
                <span className="font-mono text-[#38bdf8]">{animateSettings.preset}</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Sequence Speed</span>
                <span className="font-mono text-[#cbd5e1]">{animateSettings.speed}x</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Timeline Length</span>
                <span className="font-mono text-[#cbd5e1]">{totalFrames} Frames @ {fps} FPS</span>
              </div>
            </div>
          </div>
        )}

        {/* CASE D: Tool is 3D Generation / Model */}
        {(activeTool === 'model' || activeTool === 'image') && (
          <div className="space-y-3 p-3 rounded-xl bg-[#13151b] border border-[#222632]">
            <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#f5c518]" />
              3D AI Generator Pipeline
            </span>

            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Model Engine</span>
                <span className="font-mono text-[#f5c518]">{generationSettings.aiModel}</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Octree Depth</span>
                <span className="font-mono text-[#cbd5e1]">Not available until workflow execution</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Diffusion Steps</span>
                <span className="font-mono text-[#cbd5e1]">Workflow-defined</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Cutout RMBG</span>
                <span className="font-mono text-[#22c55e]">{generationSettings.removeBackground ? 'Requested' : 'Off'}</span>
              </div>
            </div>
          </div>
        )}

        {/* CASE E: Tool is Nodes Visual Graph */}
        {activeTool === 'nodes' && (
          <div className="space-y-3 p-3 rounded-xl bg-[#13151b] border border-[#222632]">
            <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
              <GitBranch className="w-3.5 h-3.5 text-[#f5c518]" />
              ComfyUI Pipeline Status
            </span>

            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between text-[#cbd5e1]">
                <span>Backend Status</span>
                <span className="font-mono text-[#22c55e] capitalize">{comfyStats.status}</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>GPU Device</span>
                <span className="font-mono text-[#cbd5e1] truncate">{comfyStats.gpu}</span>
              </div>
              <div className="flex justify-between text-[#cbd5e1]">
                <span>VRAM Allocation</span>
                <span className="font-mono text-[#f5c518]">{comfyStats.vramUsedGb != null && comfyStats.vramTotalGb != null ? `${comfyStats.vramUsedGb} / ${comfyStats.vramTotalGb} GB` : 'Unavailable'}</span>
              </div>
            </div>
          </div>
        )}

        {/* 4. Shading & Render Viewport Overrides */}
        <div className="space-y-2 pt-1">
          <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5 text-[#f5c518]" />
            Viewport Shading
          </span>

          <div className="grid grid-cols-3 gap-1.5">
            <button
              onClick={() => setShadingMode('textured')}
              className={`py-1.5 px-2 rounded-lg text-[10px] font-medium transition-all ${
                shadingMode === 'textured'
                  ? 'bg-[#f5c518] text-[#111216] font-bold shadow'
                  : 'bg-[#161820] text-[#9ca3af] hover:text-[#f3f4f6] border border-[#232734]'
              }`}
            >
              PBR Lit
            </button>

            <button
              onClick={() => setShadingMode('wireframe')}
              className={`py-1.5 px-2 rounded-lg text-[10px] font-medium transition-all ${
                shadingMode === 'wireframe'
                  ? 'bg-[#f5c518] text-[#111216] font-bold shadow'
                  : 'bg-[#161820] text-[#9ca3af] hover:text-[#f3f4f6] border border-[#232734]'
              }`}
            >
              Wireframe
            </button>

            <button
              onClick={() => setShadingMode('normals')}
              className={`py-1.5 px-2 rounded-lg text-[10px] font-medium transition-all ${
                shadingMode === 'normals'
                  ? 'bg-[#f5c518] text-[#111216] font-bold shadow'
                  : 'bg-[#161820] text-[#9ca3af] hover:text-[#f3f4f6] border border-[#232734]'
              }`}
            >
              Normals
            </button>

            <button
              onClick={() => setShadingMode('matcap')}
              className={`py-1.5 px-2 rounded-lg text-[10px] font-medium transition-all ${
                shadingMode === 'matcap'
                  ? 'bg-[#f5c518] text-[#111216] font-bold shadow'
                  : 'bg-[#161820] text-[#9ca3af] hover:text-[#f3f4f6] border border-[#232734]'
              }`}
            >
              MatCap
            </button>

            <button
              onClick={() => setShadingMode('basecolor')}
              className={`py-1.5 px-2 rounded-lg text-[10px] font-medium transition-all ${
                shadingMode === 'basecolor'
                  ? 'bg-[#f5c518] text-[#111216] font-bold shadow'
                  : 'bg-[#161820] text-[#9ca3af] hover:text-[#f3f4f6] border border-[#232734]'
              }`}
            >
              Albedo
            </button>

            <button
              onClick={() => setShowWireframe(!showWireframe)}
              className={`py-1.5 px-2 rounded-lg text-[10px] font-medium transition-all ${
                showWireframe
                  ? 'bg-[#6366f1] text-white font-bold'
                  : 'bg-[#161820] text-[#9ca3af] hover:text-[#f3f4f6] border border-[#232734]'
              }`}
            >
              + Wire Overlay
            </button>
          </div>
        </div>

        {/* 5. Production Export Section */}
        <div className="pt-3 border-t border-[#232732] space-y-3">
          <span className="font-bold text-[11px] text-[#8e95a5] uppercase tracking-wider flex items-center gap-1.5">
            <Download className="w-3.5 h-3.5 text-[#f5c518]" />
            Quick Export Asset
          </span>

          {/* Formats Grid */}
          <div className="grid grid-cols-5 gap-1">
            {(['glb', 'obj', 'fbx', 'usdz', 'stl'] as const).map((fmt) => (
              <button
                key={fmt}
                onClick={() => setExportFormat(fmt)}
                className={`py-1.5 rounded-lg uppercase font-mono font-bold text-[10px] transition-colors ${
                  exportFormat === fmt
                    ? 'bg-[#f5c518] text-[#111216]'
                    : 'bg-[#161820] text-[#9ca3af] hover:text-[#e5e7eb] border border-[#242834]'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>

          {/* Export Options Toggles */}
          <div className="space-y-2 text-[11px]">
            <label className="flex items-center justify-between text-[#cbd5e1] cursor-pointer">
              <span>Embed PBR Textures</span>
              <input
                type="checkbox"
                checked={embedTextures}
                onChange={(e) => setEmbedTextures(e.target.checked)}
                className="rounded accent-[#f5c518] cursor-pointer"
              />
            </label>
            <label className="flex items-center justify-between text-[#cbd5e1] cursor-pointer">
              <span>Draco Mesh Compression</span>
              <input
                type="checkbox"
                checked={dracoCompression}
                onChange={(e) => setDracoCompression(e.target.checked)}
                className="rounded accent-[#f5c518] cursor-pointer"
              />
            </label>
          </div>

          {/* Download Button */}
          <button
            id="btn-export-download"
            onClick={handleExportDownload}
            disabled={isExporting}
            className="w-full py-2.5 rounded-xl bg-[#202532] hover:bg-[#282f40] border border-[#363e52] text-[#f5c518] font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-md cursor-pointer"
          >
            {isExporting ? (
              <RefreshCw className="w-4 h-4 animate-spin text-[#f5c518]" />
            ) : exportSuccess ? (
              <Check className="w-4 h-4 text-[#22c55e]" />
            ) : (
              <Download className="w-4 h-4 text-[#f5c518]" />
            )}
            <span>
              {isExporting ? 'Packing 3D Bundle...' : exportSuccess ? 'Export Saved!' : `Download ${exportFormat.toUpperCase()} Asset`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
