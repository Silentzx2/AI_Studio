import React, { useState } from 'react';
import { 
  Box, 
  ChevronDown, 
  Layers, 
  Sliders, 
  Activity, 
  Bell, 
  User, 
  Cable, 
  GitBranch,
  Sun,
  Hexagon,
  Image as ImageIcon
} from 'lucide-react';
import { useWorkspace } from '../../store/WorkspaceContext';

export const TopHeader: React.FC = () => {
  const {
    mainNav,
    setMainNav,
    activeTool,
    setActiveTool,
    comfyStats,
    setIsComfySettingsOpen,
    setIsDccBridgeOpen
  } = useWorkspace();

  const [workspaceMenuOpen, setWorkspaceMenuOpen] = useState(false);

  return (
    <header 
      id="persistent-top-header"
      className="h-14 w-full bg-[#0d0e12] border-b border-[#21242c] px-4 flex items-center justify-between z-30 select-none flex-shrink-0"
    >
      {/* Left Branding & Mode Dropdown */}
      <div className="flex items-center gap-6">
        {/* Brand Studio Logo (NEXUS 3D) matching Reference Image */}
        <div 
          onClick={() => setMainNav('dashboard')}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="w-6 h-6 rounded-md bg-[#f5c518] flex items-center justify-center shadow-md shadow-[#f5c518]/20 group-hover:scale-105 transition-transform">
            <span className="text-[#111216] font-black text-xs">▲</span>
          </div>
          <span className="font-extrabold text-sm tracking-wider text-[#f3f4f6] uppercase font-mono">
            NEXUS 3D
          </span>
        </div>

        {/* 3D Workspace Mode Switcher Dropdown */}
        <div className="relative">
          <button
            id="btn-workspace-switcher"
            onClick={() => setWorkspaceMenuOpen(!workspaceMenuOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#16181f] border border-[#272b36] text-xs font-semibold text-[#f5c518] hover:border-[#f5c518]/50 transition-colors"
          >
            <span>3D Workspace</span>
            <ChevronDown className="w-3.5 h-3.5 text-[#9ca3af]" />
          </button>

          {workspaceMenuOpen && (
            <div className="absolute top-full left-0 mt-1.5 w-52 py-1.5 rounded-xl bg-[#181a20] border border-[#303542] shadow-2xl z-50">
              <button
                onClick={() => { setMainNav('workspace'); setActiveTool('model'); setWorkspaceMenuOpen(false); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-[#e5e7eb] hover:bg-[#232731]"
              >
                <Box className="w-4 h-4 text-[#f5c518]" />
                <span>3D Model Studio</span>
              </button>
              <button
                onClick={() => { setMainNav('workspace'); setActiveTool('retopo'); setWorkspaceMenuOpen(false); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-[#e5e7eb] hover:bg-[#232731]"
              >
                <Hexagon className="w-4 h-4 text-[#f5c518]" />
                <span>Quad Retopology</span>
              </button>
              <button
                onClick={() => { setMainNav('workspace'); setActiveTool('texture'); setWorkspaceMenuOpen(false); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-[#e5e7eb] hover:bg-[#232731]"
              >
                <Layers className="w-4 h-4 text-[#f5c518]" />
                <span>PBR Texture Studio</span>
              </button>
              <button
                onClick={() => { setMainNav('workspace'); setActiveTool('segment'); setWorkspaceMenuOpen(false); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-[#e5e7eb] hover:bg-[#232731]"
              >
                <Sliders className="w-4 h-4 text-[#f5c518]" />
                <span>Segmentation</span>
              </button>
              <button
                onClick={() => { setMainNav('workspace'); setActiveTool('rigging'); setWorkspaceMenuOpen(false); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-[#e5e7eb] hover:bg-[#232731]"
              >
                <Hexagon className="w-4 h-4 text-[#f5c518]" />
                <span>Rigging</span>
              </button>
              <button
                onClick={() => { setMainNav('workspace'); setActiveTool('nodes'); setWorkspaceMenuOpen(false); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-[#e5e7eb] hover:bg-[#232731]"
              >
                <GitBranch className="w-4 h-4 text-[#f5c518]" />
                <span>ComfyUI Node Graph</span>
              </button>
            </div>
          )}
        </div>

        {/* Top Navigation Links */}
        <nav className="flex items-center gap-2 text-xs font-medium">
          <button
            id="nav-link-home"
            onClick={() => setMainNav('dashboard')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              mainNav === 'dashboard'
                ? 'text-[#f5c518] font-bold'
                : 'text-[#9ca3af] hover:text-[#f3f4f6]'
            }`}
          >
            Home
          </button>

          <button
            id="nav-link-assets"
            onClick={() => setMainNav('assets')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              mainNav === 'assets'
                ? 'text-[#f5c518] font-bold'
                : 'text-[#9ca3af] hover:text-[#f3f4f6]'
            }`}
          >
            Assets
          </button>

          <button
            id="nav-link-system"
            onClick={() => setMainNav('system')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${mainNav === 'system' ? 'text-[#f5c518] font-bold' : 'text-[#9ca3af] hover:text-[#f3f4f6]'}`}
          >
            System
          </button>

          <button
            id="nav-link-pipeline"
            onClick={() => {
              setMainNav('workspace');
              setActiveTool('nodes');
            }}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTool === 'nodes'
                ? 'text-[#f5c518] font-bold'
                : 'text-[#9ca3af] hover:text-[#f3f4f6]'
            }`}
          >
            Pipeline
          </button>
        </nav>
      </div>

      {/* Right DCC Bridge, ComfyUI 3D Status, Notifications, Profile (Personal Use - No Billing/Credits) */}
      <div className="flex items-center gap-3.5">
        {/* DCC Bridge Button with Version (Reference Image) */}
        <button
          id="btn-dcc-bridge"
          onClick={() => setIsDccBridgeOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#16181f] border border-[#272b36] hover:border-[#3b4150] text-xs text-[#cbd5e1] transition-colors"
          title="Connect to Blender / Unreal Engine / Maya via DCC Bridge"
        >
          <Cable className="w-3.5 h-3.5 text-[#f5c518]" />
          <span className="font-medium">DCC Bridge</span>
                  </button>

        {/* Live ComfyUI Backend Indicator */}
        <button
          id="btn-comfy-status-pill"
          onClick={() => setIsComfySettingsOpen(true)}
          className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-xs font-mono transition-all ${
            comfyStats.status === 'online'
              ? 'bg-[#151921] border-[#2563eb]/40 text-[#93c5fd] hover:border-[#3b82f6]'
              : 'bg-[#1e1616] border-[#ef4444]/40 text-[#fca5a5] hover:border-[#ef4444]'
          }`}
          title="Configure ComfyUI + ComfyUI-3D-Pack local server backend"
        >
          <div className={`w-2 h-2 rounded-full ${comfyStats.status === 'online' ? 'bg-[#22c55e] animate-pulse' : 'bg-[#ef4444]'}`} />
          <span className="text-[11px] font-sans font-medium text-[#cbd5e1]">ComfyUI 3D</span>
        </button>

        {/* Brightness / Theme Icon */}
        <button
          onClick={() => setIsComfySettingsOpen(true)}
          className="p-1.5 rounded-lg text-[#9ca3af] hover:text-[#f3f4f6] hover:bg-[#1c1e24] transition-colors"
          title="Settings"
        >
          <Sun className="w-4 h-4" />
        </button>

        <button
          aria-label="Notifications"
          className="p-1.5 rounded-lg text-[#9ca3af] hover:text-[#f3f4f6] hover:bg-[#1c1e24] transition-colors"
          title="Notifications"
        >
          <Bell className="w-4 h-4" />
        </button>

        {/* Profile Avatar */}
        <div 
          onClick={() => setIsComfySettingsOpen(true)}
          className="w-7 h-7 rounded-full bg-[#242732] border border-[#3c4252] flex items-center justify-center text-xs font-bold text-[#f5c518] cursor-pointer hover:border-[#f5c518] transition-colors"
        >
          <User className="w-4 h-4 text-[#cbd5e1]" />
        </div>
      </div>
    </header>
  );
};
