import React, { useEffect } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useWorkspace } from '../../store/WorkspaceContext';
import { TopHeader } from '../Header/TopHeader';
import { LeftNavigation } from '../ToolRail/LeftNavigation';
import { MeshViewer } from '../Viewport/MeshViewer';
import { GeneratePanel } from '../ToolPanel/GeneratePanel';
import { TexturePanel } from '../ToolPanel/TexturePanel';
import { RemeshPanel } from '../ToolPanel/RemeshPanel';
import { AnimatePanel } from '../ToolPanel/AnimatePanel';
import { SegmentationPanel } from '../ToolPanel/SegmentationPanel';
import { RiggingPanel } from '../ToolPanel/RiggingPanel';
import { SecondaryPanel } from '../ToolPanel/SecondaryPanels';
import { NodesPanel } from '../ToolPanel/NodesPanel';
import { RightAssetsPanel } from '../RightPanel/RightAssetsPanel';
import { RightPropertyPanel } from '../RightPanel/RightPropertyPanel';
import { RightPromptPanel } from '../RightPanel/RightPromptPanel';
import { OutputsPage } from '../Dashboard/OutputsPage';
import { SystemPage } from '../Dashboard/SystemPage';
import { StudioDashboard } from '../Dashboard/StudioDashboard';
import { ComfySettingsModal } from '../Modals/ComfySettingsModal';
import { DccBridgeModal } from '../Modals/DccBridgeModal';
import { ExportModal } from '../Modals/ExportModal';
import { ComfyProgressOverlay } from '../Notifications/ComfyProgressOverlay';
import { FolderOpen, Sliders } from 'lucide-react';
import { ToolType } from '../../types';
import { comfyClient } from '../../lib/comfy';

// Map path routes to workspace tools
const ROUTE_TO_TOOL: Record<string, ToolType> = {
  '/': 'model',
  '/workspace': 'model',
  '/workspace/generate': 'model',
  '/generate': 'model',
  '/model': 'model',
  '/workspace/pre-process': 'image',
  '/image': 'image',
  '/workspace/segment': 'segment',
  '/segment': 'segment',
  '/workspace/retopo': 'retopo',
  '/retopo': 'retopo',
  '/workspace/remesh': 'remesh',
  '/remesh': 'remesh',
  '/workspace/texture': 'texture',
  '/texture': 'texture',
  '/workspace/edit': 'edit',
  '/edit': 'edit',
  '/workspace/upscale': 'upscale',
  '/upscale': 'upscale',
  '/workspace/pbr': 'pbr',
  '/pbr': 'pbr',
  '/workspace/animate': 'animate',
  '/animate': 'animate',
  '/workspace/rigging': 'rigging',
  '/rigging': 'rigging',
  '/workspace/nodes': 'nodes',
  '/nodes': 'nodes'
};

const TOOL_TO_ROUTE: Record<ToolType, string> = {
  model: '/workspace/generate',
  image: '/workspace/pre-process',
  segment: '/workspace/segment',
  retopo: '/workspace/retopo',
  remesh: '/workspace/remesh',
  texture: '/workspace/texture',
  edit: '/workspace/edit',
  upscale: '/workspace/upscale',
  pbr: '/workspace/pbr',
  animate: '/workspace/animate',
  rigging: '/workspace/rigging',
  nodes: '/workspace/nodes'
};

export const WorkspaceShell: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const { 
    mainNav, 
    setMainNav,
    activeTool, 
    setActiveTool,
    rightPanelMode, 
    setRightPanelMode, 
    isLeftPanelOpen,
    isRightPanelOpen
  } = useWorkspace();

  useEffect(() => {
    const comfyHost = searchParams.get('comfy');
    if (comfyHost) {
      try {
        const url = new URL(comfyHost);
        if (url.protocol === 'http:' || url.protocol === 'https:') {
          comfyClient.setHost(url.toString().replace(/\/$/, ''));
        }
      } catch {
        // Ignore invalid query-string overrides and keep the configured host.
      }
    }
  }, [searchParams]);

  // Synchronize URL Hash route with activeTool & mainNav
  useEffect(() => {
    const pathname = location.pathname.toLowerCase();

    if (pathname === '/dashboard' || pathname === '/home') {
      if (mainNav !== 'dashboard') setMainNav('dashboard');
      return;
    }
    if (pathname === '/outputs' || pathname === '/assets') {
      if (mainNav !== 'assets') setMainNav('assets');
      return;
    }
    if (pathname === '/system') {
      if (mainNav !== 'system') setMainNav('system');
      return;
    }

    if (mainNav !== 'workspace') setMainNav('workspace');

    const matchedTool = ROUTE_TO_TOOL[pathname] || 'model';
    if (matchedTool !== activeTool) {
      setActiveTool(matchedTool);
    }
  }, [location.pathname]);

  // Synchronize tool changes back to URL route without refreshing
  useEffect(() => {
    if (mainNav === 'dashboard') { if (location.pathname !== '/dashboard') navigate('/dashboard', { replace: true }); return; }
    if (mainNav === 'assets') { if (location.pathname !== '/outputs') navigate('/outputs', { replace: true }); return; }
    if (mainNav === 'system') { if (location.pathname !== '/system') navigate('/system', { replace: true }); return; }

    const expectedRoute = TOOL_TO_ROUTE[activeTool] || '/generate';
    if (location.pathname !== expectedRoute) {
      navigate(expectedRoute, { replace: true });
    }
  }, [activeTool, mainNav]);

  // Render appropriate tool configuration panel on the left control bar
  const renderToolPanel = () => {
    switch (activeTool) {
      case 'image':
        return <SecondaryPanel tool="image" />;
      case 'model':
        return <GeneratePanel />;
      case 'segment':
        return <SegmentationPanel />;
      case 'texture':
        return <TexturePanel />;
      case 'remesh':
        return <RemeshPanel />;
      case 'animate':
        return <AnimatePanel />;
      case 'rigging':
        return <RiggingPanel />;
      case 'retopo':
      case 'edit':
      case 'upscale':
      case 'pbr':
        return <SecondaryPanel tool={activeTool} />;
      default:
        return <GeneratePanel />;
    }
  };

  return (
    <div id="forge3d-app-root" className="flex flex-col h-screen w-screen overflow-hidden bg-[#0d0e12] text-[#f3f4f6]">
      {/* 1. Persistent Top Header */}
      <TopHeader />

      {/* 2. Main Middle Workspace Area */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Left Tool Rail (Always loaded & persistent) */}
        <LeftNavigation />

        {/* Dashboard View Mode */}
        {mainNav === 'dashboard' ? (
          <StudioDashboard />
        ) : mainNav === 'assets' ? (
          <OutputsPage />
        ) : mainNav === 'system' ? (
          <SystemPage />
        ) : (
          /* 3D Workspace & Nodes View Mode - Viewport stays mounted and preserves 3D state */
          <div className="flex flex-1 overflow-hidden relative">
            {/* Left Context Tool Panel (320px) - Visible when tool is not 'nodes' */}
            {activeTool !== 'nodes' && isLeftPanelOpen && (
              <aside 
                id="context-tool-panel-container"
                className="w-80 h-full bg-[#101115] border-r border-[#21242c] flex flex-col flex-shrink-0 z-10 overflow-hidden"
              >
                {renderToolPanel()}
              </aside>
            )}

            {/* Central workspace stage: viewport stays mounted for every tool, including Nodes. */}
            <main id="center-viewport-stage" className="flex-1 h-full relative overflow-hidden bg-[#0a0b0e]">
              <MeshViewer />
              {activeTool === 'nodes' && (
                <div className="absolute inset-0 z-30 bg-[#0a0b0e]/96">
                  <NodesPanel />
                </div>
              )}
            </main>

            {/* Right Asset Library & Property Inspector (320px) */}
            {activeTool !== 'nodes' && isRightPanelOpen && (
              <aside 
                id="right-inspector-assets-column"
                className="w-80 h-full bg-[#101115] border-l border-[#21242c] flex flex-col flex-shrink-0 z-10 overflow-hidden"
              >
                {/* Right Tab Switcher */}
                <div className="flex items-center p-1 bg-[#0f1014] border-b border-[#21242c]">
                  <button
                    id="tab-btn-assets"
                    onClick={() => setRightPanelMode('assets')}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                      rightPanelMode === 'assets'
                        ? 'bg-[#1c1f28] text-[#f5c518] shadow-sm'
                        : 'text-[#8e95a5] hover:text-[#e5e7eb]'
                    }`}
                  >
                    <FolderOpen className="w-3.5 h-3.5" />
                    <span>Assets</span>
                  </button>

                  <button
                    id="tab-btn-prompt"
                    onClick={() => setRightPanelMode('prompt')}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                      rightPanelMode === 'prompt' ? 'bg-[#1c1f28] text-[#f5c518] shadow-sm' : 'text-[#8e95a5] hover:text-[#e5e7eb]'
                    }`}
                  >
                    <span>Prompt</span>
                  </button>

                  <button
                    id="tab-btn-properties"
                    onClick={() => setRightPanelMode('properties')}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                      rightPanelMode === 'properties' || rightPanelMode === 'property'
                        ? 'bg-[#1c1f28] text-[#f5c518] shadow-sm'
                        : 'text-[#8e95a5] hover:text-[#e5e7eb]'
                    }`}
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Property</span>
                  </button>
                </div>

                {/* Tab Content */}
                <div className="flex-1 overflow-hidden">
                  {rightPanelMode === 'assets' ? <RightAssetsPanel /> : rightPanelMode === 'prompt' ? <RightPromptPanel /> : <RightPropertyPanel />}
                </div>
              </aside>
            )}
          </div>
        )}
      </div>

      {/* Global Real-time Progress & Toast Overlay */}
      <ComfyProgressOverlay />

      {/* Global Modals */}
      <ComfySettingsModal />
      <DccBridgeModal />
      <ExportModal />
    </div>
  );
};
