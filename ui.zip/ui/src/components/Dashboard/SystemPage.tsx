import React from 'react';
import { Cpu, HardDrive, Server, Activity } from 'lucide-react';
import { useWorkspace } from '../../store/WorkspaceContext';

const value = (v: unknown) => v == null ? 'Unavailable' : String(v);

export const SystemPage: React.FC = () => {
  const { comfyStats, assets } = useWorkspace();
  return (
    <div className="flex-1 overflow-y-auto bg-[#0d0e12] p-6 text-[#f3f4f6]">
      <div className="mx-auto max-w-6xl space-y-5">
        <div><h1 className="text-2xl font-black">System</h1><p className="mt-1 text-xs text-[#8e95a5]">Live runtime information from ComfyUI.</p></div>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-[#242834] bg-[#14161c] p-4"><Server className="mb-3 h-4 w-4 text-[#f5c518]" /><div className="text-[10px] text-[#707786]">Status</div><div className="mt-1 text-sm font-bold">{comfyStats.status}</div></div>
          <div className="rounded-2xl border border-[#242834] bg-[#14161c] p-4"><Cpu className="mb-3 h-4 w-4 text-[#f5c518]" /><div className="text-[10px] text-[#707786]">GPU</div><div className="mt-1 truncate text-sm font-bold">{value(comfyStats.gpu)}</div></div>
          <div className="rounded-2xl border border-[#242834] bg-[#14161c] p-4"><Activity className="mb-3 h-4 w-4 text-[#f5c518]" /><div className="text-[10px] text-[#707786]">VRAM</div><div className="mt-1 text-sm font-bold">{comfyStats.vramUsedGb != null && comfyStats.vramTotalGb != null ? `${comfyStats.vramUsedGb} / ${comfyStats.vramTotalGb} GB` : 'Unavailable'}</div></div>
          <div className="rounded-2xl border border-[#242834] bg-[#14161c] p-4"><HardDrive className="mb-3 h-4 w-4 text-[#f5c518]" /><div className="text-[10px] text-[#707786]">History Outputs</div><div className="mt-1 text-sm font-bold">{assets.length}</div></div>
        </div>
        <div className="rounded-2xl border border-[#242834] bg-[#14161c] p-4 space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-[#707786]">ComfyUI</span><span>{value(comfyStats.comfyVersion)}</span></div>
          <div className="flex justify-between"><span className="text-[#707786]">Python</span><span>{value(comfyStats.pythonVersion)}</span></div>
          <div className="flex justify-between"><span className="text-[#707786]">PyTorch</span><span>{value(comfyStats.torchVersion)}</span></div>
          <div className="flex justify-between"><span className="text-[#707786]">Queue</span><span>{comfyStats.queueRunning} running / {comfyStats.queuePending} pending</span></div>
          <div className="flex justify-between"><span className="text-[#707786]">Host</span><span className="font-mono">{comfyStats.host}</span></div>
        </div>
      </div>
    </div>
  );
};
