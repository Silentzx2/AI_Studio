import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { WorkspaceProvider } from './store/WorkspaceContext';
import { WorkspaceShell } from './components/Workspace/WorkspaceShell';

export default function App() {
  return (
    <BrowserRouter>
      <WorkspaceProvider>
        <WorkspaceShell />
      </WorkspaceProvider>
    </BrowserRouter>
  );
}
